import React from "react";

export function Transfer({ transferTokens, tokenSymbol }) {
  return (
    <div>
      <h4>Transfer</h4>
      <form
        onSubmit={(event) => {
          // This function just calls the transferTokens callback with the
          // form's data.
          console.log("----this?---");
          event.preventDefault();

          const formData = new FormData(event.target);
          const to = formData.get("to");
          const tokenUri = formData.get("token_uri");
          console.log("----here---", to, tokenUri);
          if (to && tokenUri) {
            console.log("====here??===");
            transferTokens(to, tokenUri);
          }
        }}
      >
        <div className="form-group">
          <label>Amount of {tokenSymbol}</label>
          <input
            className="form-control"
            type="text"
            name="token_uri"
            placeholder="token uri"
            required
          />
        </div>
        <div className="form-group">
          <label>Recipient address</label>
          <input className="form-control" type="text" name="to" required />
        </div>
        <div className="form-group">
          <input className="btn btn-primary" type="submit" value="Transfer" />
        </div>
      </form>
    </div>
  );
}
